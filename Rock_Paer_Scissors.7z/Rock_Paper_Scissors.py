from flask import Flask,render_template,request
import random

app = Flask(__name__)

ROCK_ACTION=0
PAPER_ACTION=1
SCISSORS_ACTION=2
comp_num=random.randint(0,2)
print(comp_num)

@app.route("/",methods=['GET','POST'])

def fun():
    global comp_num,counter
    message=''
    if request.method=='POST':
        form=request.form
        user_guess=int(form['guess'])
        if comp_num==user_guess:
            message="It's tie"
            return render_template("game_over.html",message=message)
        elif user_guess==0:
            if comp_num==2:
                message="Rock smashes scissors! You win!"
                return render_template("game_over.html",message=message)
            else:
                message="Paper covers rock! You lose."
                return render_template("game_over.html",message=message)
        elif user_guess==1:
            if comp_num==0:
                message="Paper covers rock! You win!"
                return render_template("game_over.html",message=message)
            else:
                message="Scissors cuts paper! You lose."
                return render_template("game_over.html",message=message)
        elif user_guess==2:
            if comp_num==1:
                message="Scissors cuts paper! You win!"
                return render_template("game_over.html",message=message)
            else:
                message="Rock smashes scissors! You lose."
                return render_template("game_over.html",message=message)
            
    return render_template("guess.html",message=message)



if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
    
